package com.ollierstore.app;

import android.app.*;
import android.os.*;
import android.provider.MediaStore;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import android.widget.Toast;
import android.util.Base64;
import java.io.*;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String HOME = "https://ollierstore.rf.gd/?i=1";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false);
        s.setSupportMultipleWindows(true); s.setJavaScriptCanOpenWindowsAutomatically(true);
        webView.setBackgroundColor(Color.WHITE);
        webView.addJavascriptInterface(new DownloadBridge(this), "AndroidDownload");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u=r.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://")) { v.loadUrl(u); return true; }
                return false;
            }
            @Override public void onPageFinished(WebView v, String url) { injectDownloadBridge(v); }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            DownloadBridge.startUrlDownload(this, url, userAgent, contentDisposition, mimeType);
        });
        webView.loadUrl(HOME);
    }

    private void injectDownloadBridge(WebView v) {
        String js = "javascript:(function(){try{" +
            "if(window.__ollierDlInstalled)return;window.__ollierDlInstalled=true;" +
            "var oldClick=HTMLAnchorElement.prototype.click;" +
            "HTMLAnchorElement.prototype.click=function(){var a=this,u=a.href||'',n=a.download||'download';" +
            "if(u.indexOf('blob:')===0){fetch(u).then(function(r){return r.blob()}).then(function(b){" +
            "var fr=new FileReader();fr.onloadend=function(){try{AndroidDownload.saveBase64(n,b.type||'application/octet-stream',String(fr.result).split(',')[1]);}catch(e){}};fr.readAsDataURL(b);" +
            "}).catch(function(){oldClick.call(a)});return;}oldClick.call(a)};" +
            "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;if(a&&a.href&&a.href.indexOf('blob:')===0){e.preventDefault();e.stopPropagation();a.click();}},true);" +
            "}catch(e){}})();";
        v.evaluateJavascript(js, null);
    }

    @Override public void onBackPressed() { if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }

    public static class DownloadBridge {
        private final Context ctx;
        private final Activity activity;
        DownloadBridge(Activity a){activity=a;ctx=a.getApplicationContext();}
        @JavascriptInterface public void saveBase64(String filename, String mime, String base64){
            try {
                if(filename==null||filename.trim().isEmpty()) filename="download";
                byte[] data=Base64.decode(base64,Base64.DEFAULT);
                String safe=filename.replaceAll("[\\\\/:*?\"<>|]","_");
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues cv=new ContentValues(); cv.put(MediaStore.Downloads.DISPLAY_NAME,safe); cv.put(MediaStore.Downloads.MIME_TYPE,mime); cv.put(MediaStore.Downloads.IS_PENDING,1);
                    Uri uri=ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
                    if(uri==null) throw new IOException("Downloads indisponible");
                    try(OutputStream os=ctx.getContentResolver().openOutputStream(uri)){os.write(data);}
                    cv.clear();cv.put(MediaStore.Downloads.IS_PENDING,0);ctx.getContentResolver().update(uri,cv,null,null);
                } else {
                    File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); if(!dir.exists())dir.mkdirs();
                    try(FileOutputStream os=new FileOutputStream(new File(dir,safe))){os.write(data);}
                }
                activity.runOnUiThread(()->Toast.makeText(ctx,"✓ Téléchargé dans Téléchargements",Toast.LENGTH_LONG).show());
            } catch(Exception e){activity.runOnUiThread(()->Toast.makeText(ctx,"❌ Téléchargement impossible",Toast.LENGTH_LONG).show());}
        }
        static void startUrlDownload(Context c,String url,String ua,String disposition,String mime){
            try { DownloadManager dm=(DownloadManager)c.getSystemService(Context.DOWNLOAD_SERVICE); Uri u=Uri.parse(url); DownloadManager.Request r=new DownloadManager.Request(u); r.setMimeType(mime); if(ua!=null)r.addRequestHeader("User-Agent",ua); r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "OllierStore_download"); dm.enqueue(r); Toast.makeText(c,"Téléchargement lancé",Toast.LENGTH_SHORT).show(); }
            catch(Exception e){Toast.makeText(c,"❌ Téléchargement impossible",Toast.LENGTH_LONG).show();}
        }
    }
}
