# OllierStore Android
Application WebView légère pour https://ollierstore.rf.gd/?i=1.
La gestion native des téléchargements intercepte les liens Blob utilisés par PDF/XLS/CSV et enregistre les fichiers dans le dossier Téléchargements Android.
